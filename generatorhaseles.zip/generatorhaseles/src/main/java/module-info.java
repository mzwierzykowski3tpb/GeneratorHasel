module com.example.generatorhaseles {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.generatorhaseles to javafx.fxml;
    exports com.example.generatorhaseles;
}